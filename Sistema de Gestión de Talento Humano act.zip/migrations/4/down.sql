
DROP TABLE companies;
